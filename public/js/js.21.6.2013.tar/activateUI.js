//pongo algunas funciones de com.cayt como globales, @todo habria que usarlas desde el modulo...
window.ajaxLoadTab=com.cayt.ajaxLoadTab;
window.ajaxLoadPage=com.cayt.ajaxLoadPage;


//getTabContainer devuelve El Objeto Contenedor del elemento definido por "selector" , o undefined
$.getTabContainer=function(selector){
	return $(selector).parents( "div.ui-tabs-panel" );
}


/*
 * 
 $(window).bind('unload',function(e){
    e.preventDefault();
    if(confirm('Seguro Desea Cerrar la Aplicacion?')){
    	return true;
    }else{
    	return false;
    }
});
*/
window.onbeforeunload = function(){
	var miArray = new Array() ;
	$('div#CenterPane>div#tabs>ul.ui-tabs-nav>li a').each(
			function() {
				if (($(this).find('span').text()!='') && ($(this).find('span').text()!=undefined)
						 && ($(this).data('tab_url')!='/default/login/recargar-acl/') 
						 && ($(this).data('tab_url')!='/default/login/logout/')
						 && ($(this).data('tab_url')!=undefined)){
					miArray.push($(this).find('span').text()+"(split_data)"+$(this).data('tab_url'));
				}
			}
	);

	//$.cookie('maintabs', miArray.join("(split_tabs)"), { path: '/', expires: 10 });
	/** @todo ya no se guarda mas en cookies, cambiar los nombres de las variables!!!
	 * */
	//$('<div>').load('/default/opciones/guardar-maintabs/' , {maintabs: (miArray.join("(split_tabs)"))} );

	return '';
};

$(document).ready(function() {
	//Activar Layout	
	$('body').layout({			
						resizerClass: 'ui-state-default'							
				        ,west__onresize: function (pane, $Pane) {
							JQuery('#menu-accordion').parent().height(($Pane.innerHeight()-50));
						}
						// applyDefaultStyles: true 
						//,	north__size:			35
						,	south__size:			40
			
						,	west__minSize:			100
						,	east__minSize:			1						
						,	east__maxSize:			Math.floor(screen.availWidth / 2) // 1/2 screen width
						,  east__initClosed:                   true
	});	
	
	//activar Tabs
	window.trigger_tab_init=function(){};
	window.maintab =jQuery('#tabs','#CenterPane').tabs({
		show: function(event, ui) { 
					$("#tabs>div[@id^='tabs']>div:first-child").removeAttr('id').removeAttr('name');
					$(ui.panel).children('div:first-child').attr('id','page');
					window.trigger_tab_init($(ui.panel).attr('id'));
					window.trigger_tab_init=function(){};
					return true;
				},

		add: function(e, ui) {
			// append close thingy
	        $(ui.tab).parents('li:first')
	            .append('<span class="ui-tabs-close ui-icon ui-icon-close" title="Close Tab"></span>')
	            .find('span.ui-tabs-close')
	            .click(function() {
	            	window.maintab.tabs('remove', $('li', maintab).index($(this).parents('li:first')[0]));
	            });
	        $(ui.tab).parents('li:first').contextMenu({
												menu: 'menu-contextual-tabs'
											}, function(action, el, pos) {
												if (action=='refresh'){
													window.maintab.tabs( 'load' , $('li', maintab).index($(el)) ); //reload
												}
												if (action=='close-this'){
													window.maintab.tabs('remove', $('li', maintab).index($(el))); //close
												}
												if (action=='close-others'){
													var max=$('div#CenterPane>div#tabs>ul.ui-tabs-nav>li a').size();
													for (var i = max-1; i >= 1; i--) {
														if (i!=$('li', maintab).index($(el))){
															window.maintab.tabs('remove', i); //close
														}
													}													
												}
												/*
												alert(
													'Action: ' + action + '\n\n' +
													'Element text: ' + $(el).text() + '\n\n' + 
													'X: ' + pos.x + '  Y: ' + pos.y + ' (relative to element)\n\n' + 
													'X: ' + pos.docX + '  Y: ' + pos.docY+ ' (relative to document)'
													);
												*/
											});
	        // select just added tab
	        window.maintab.tabs('select', '#' + ui.panel.id);
	    },
	    cache: true,
	    ajaxOptions: { async: false } 
	});    	
	
	/** @todo mejorar esto del tamaño del menu y el evento resize del panel */
	$('#menu-accordion').parent().height($('#menu-accordion').parent().parent().height()-50);
	//Activar Accordion Menu
	$("#menu-accordion").accordion({ active: parseInt("0"+$.cookie('menu-accordion')) ,
										change: function(event, ui) { 
													var CurrentIdx = $("#menu-accordion h3").index($("#menu-accordion h3.ui-state-active"));
													$.cookie('menu-accordion', CurrentIdx, { path: '/', expires: 10 });
												} , 
										fillSpace:true , 
										collapsible:true
									});
	
	
	
	//Activar BlockUI (para los Ajax)
	$.blockUI.defaults.message=  '<h1><img src="/images/busy.gif" /> Procesando...</h1>';
	$().ajaxStart($.blockUI).ajaxStop($.unblockUI).ajaxError( function () {
			$.unblockUI();
			//alert("Hubo un error en el retorno del Ajax");
		});
	
	// Activar efecto on over de los Items del Menu
	$('a.menu-item').hover(
			function(){ 
				$(this).addClass("ui-state-hover");
				//$(this).addClass("ui-state-highlight");
			},
			function(){ 
				$(this).removeClass("ui-state-hover"); 
				//$(this).removeClass("ui-state-highlight");
			}
		);

	
	//levanto si existe informacion de los ultimos tabs abiertos
	// var cookie_maintabs = unescape($.cookie('maintabs'));
	/** @todo ya no se guarda mas en cookies, cambiar los nombres de las variables!!!
	 * */
	window.cookie_maintabs=null;	
	$.ajax({
		  url: '/default/opciones/traer-maintabs/',
		  async:false, //llamada sincronica, bloqueara el browser hasta traer la informacion
		  success: function(data) {
		  		window.cookie_maintabs=data;
		  }
		});
	
	var cookie_maintabs = window.cookie_maintabs;
	
	if ((cookie_maintabs!='') && (cookie_maintabs!=null) && (cookie_maintabs!='null') && (window.estoy_en_pantalla_login!=true) ){
		if (confirm('Bienvenido a CAYT\n ¿Desea Restaurar su último Espacio de Trabajo?')){
			var arr_maintabs=cookie_maintabs.split("(split_tabs)");	
			for(var i=0; i< arr_maintabs.length; i++) {
				var data=arr_maintabs[i].split("(split_data)");
				com.cayt.ajaxLoadTab(data[1], data[0]); 
		        //alert(data[0]+"@"+data[1]);
		    }
		}
	}
	
	$.ajax({
		  url: '/default/opciones/traer-url-estilo/',
		  async:true, 
		  success: function(data) {
				if (data!=''){
					$("#linc").attr({ href: data });
				}
		  }
		});
	
	//deshabilito boton secundario mouse
	//$().bind("contextmenu",function(){return !1;});
});

